CREATE USER 'pokemonusr'@'localhost' IDENTIFIED BY 'pokemonpsw';
CREATE DATABASE pokemondb
  DEFAULT CHARACTER SET utf8
  DEFAULT COLLATE utf8_general_ci;
GRANT SELECT, INSERT, UPDATE, DELETE ON pokemondb.* TO 'pokemonusr'@'localhost';
USE pokemondb;
CREATE TABLE `pokemontypes` (
    `id` INT(4) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(10) NOT NULL UNIQUE,
    `attack` VARCHAR(20) NOT NULL,
    PRIMARY KEY (`id`)
);
CREATE TABLE `pokemons` (
    `id` INT(4) NOT NULL,
    `name` VARCHAR(10) NOT NULL UNIQUE,
    `height` DOUBLE DEFAULT 0.0,
    `weight` DOUBLE DEFAULT 0.0,
    `genre` ENUM('male', 'female', 'both'),
    `type_id` INT(4),
    PRIMARY KEY (`id`)
);
/* Si implementeu l'evolució, heu d'afegir un camp a la taula 'pokemons' i la com a clau forana reflexiva */
ALTER TABLE `pokemons` 
    ADD CONSTRAINT `fk_pokemon` FOREIGN KEY (type_id) 
    REFERENCES pokemontypes(id)
    ON UPDATE CASCADE ON DELETE RESTRICT;
/* Si implementeu l'evolució, heu d'afegir la restricció d'integritat de la clau forana reflexiva de la taula 'pokemons' */

/* FALTA REALITZAR ELS INSERTS A LES DUES TAULES */

/* INSERT INTO pokemons VALUES 
    (1, "Bulbasur", 0.7, 6.9, 'both', 1);*/
