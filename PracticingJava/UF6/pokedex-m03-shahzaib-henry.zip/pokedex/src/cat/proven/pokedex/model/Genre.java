package cat.proven.pokedex.model;

/**
 *
 * @author ProvenSoft
 */
public enum Genre {
    male, female, both
}
